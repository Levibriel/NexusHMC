import os
import pandas as pd

PARQUET_PATH = os.path.join("data", "planes_raw.parquet")

F1 = 0.85
F_REL = 0.80
F12 = 0.90
F_PROD = 1.00 + (0.85 / 7.0)

FACTORES_HORARIOS = [
    F1, F_PROD, F_PROD, F_PROD, F_PROD,
    F_REL, F_REL, F_REL,
    F_PROD, F_PROD, F_PROD,
    F12
]

def obtener_plan_turno(fecha: str, turno: str = "A") -> dict:
    if not os.path.exists(PARQUET_PATH):
        raise FileNotFoundError(f"Repositorio histórico no encontrado en {PARQUET_PATH}")

    df = pd.read_parquet(PARQUET_PATH, filters=[("fecha", "==", fecha)])
    if df.empty:
        raise ValueError(f"No existe planificación cargada para la fecha {fecha}")

    fila = df.iloc[0]
    ton_dia = float(fila["ton_plan_dia"])
    ton_turno = round(ton_dia / 2.0, 2)
    t_base = ton_turno / 12.0

    vector_horas = [round(t_base * f, 2) for f in FACTORES_HORARIOS]
    
    # Cuadratura de redondeo a nivel de centavos sobre la última hora
    diferencia = round(ton_turno - sum(vector_horas), 2)
    vector_horas[-1] = round(vector_horas[-1] + diferencia, 2)

    return {
        "periodo": str(fila["periodo"]),
        "fecha": str(fila["fecha"]),
        "semana": str(fila["semana"]),
        "fase": str(fila["fase"]),
        "ton_plan_dia": ton_dia,
        "turno": turno,
        "ton_plan_turno": ton_turno,
        "t_base": round(t_base, 2),
        "perfil_horario": vector_horas
    }


def obtener_plan_flota(fecha_str: str, turno_str: str) -> dict[str, dict[str, float]]:
    """
    Retorna el diccionario de metas planificadas ajustadas al turno.
    Aplica factor 0.5 (12h) para turnos 'A' o 'B' y 1.0 (24h) para 'A+B' o 'BOTH'.
    """
    df_plan = pd.read_parquet("data/plan_kpi_equipos.parquet")
    df_fecha = df_plan[df_plan["fecha"].astype(str) == fecha_str]

    # Factor de escala por duración de turno
    factor_turno = 0.5 if str(turno_str).upper() in ["A", "B"] else 1.0

    plan_dict = {}
    for _, row in df_fecha.iterrows():
        eq_id = str(row["equipo_id"]).replace("-", "").upper()
        hrs_nom = float(row.get("hrs_nom_plan", 12.0)) * factor_turno
        hrs_disp = float(row.get("hrs_disp_plan", 0.0)) * factor_turno
        hrs_op = float(row.get("hrs_op_plan", 0.0)) * factor_turno
        ton_plan = round(float(row.get("ton_plan", 0.0)) * factor_turno, 1)

        plan_dict[eq_id] = {
            "hrs_nom_plan": hrs_nom,
            "df_plan_pct": round(float(row.get("df_plan", 0.0)) * 100.0, 1),
            "hrs_disp_plan": hrs_disp,
            "utbd_plan_pct": round(float(row.get("utbd_plan", 0.0)) * 100.0, 1),
            "hrs_op_plan": hrs_op,
            "rend_plan": float(row.get("rend_plan", 0.0)),
            "ton_plan": ton_plan,
        }

    return plan_dict