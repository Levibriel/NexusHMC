lucide.createIcons();
let seagullChartInstance = null;
let sidebarExpanded = true;

// Inicialización del Tema: Por defecto Modo Claro
if (localStorage.getItem('theme') === 'dark') {
  document.documentElement.classList.add('dark');
} else {
  document.documentElement.classList.remove('dark');
  localStorage.setItem('theme', 'light');
}

// Registrar Plugin DataLabels de forma segura si está disponible
if (typeof ChartDataLabels !== 'undefined') {
  Chart.register(ChartDataLabels);
}

function fmt(num) {
  if (num === null || num === undefined || isNaN(num)) return '0';
  return Math.round(num)
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

let sidebarVisible = true;
function toggleSidebar() {
  const sidebar = document.getElementById('sidebar');
  const mainContainer = document.getElementById('main-container');
  const toggleIcon = document.getElementById('sidebar-toggle-icon');

  if (window.innerWidth < 768) {
    sidebar.classList.toggle('-translate-x-full');
  } else {
    sidebarVisible = !sidebarVisible;
    if (sidebarVisible) {
      sidebar.classList.remove(
        'md:-translate-x-full',
        '-translate-x-full',
        'md:translate-x-full'
      );
      sidebar.classList.add('md:translate-x-0');
      mainContainer.classList.remove('md:ml-0');
      mainContainer.classList.add('md:ml-64');
      if (toggleIcon) toggleIcon.setAttribute('data-lucide', 'chevrons-left');
    } else {
      sidebar.classList.remove('md:translate-x-0', 'translate-x-0');
      sidebar.classList.add('md:-translate-x-full');
      mainContainer.classList.remove('md:ml-64');
      mainContainer.classList.add('md:ml-0');
      if (toggleIcon) toggleIcon.setAttribute('data-lucide', 'chevrons-right');
    }

    if (window.lucide) lucide.createIcons();
    setTimeout(() => {
      if (seagullChartInstance) {
        seagullChartInstance.resize();
      }
    }, 310);
  }
}

function toggleTheme() {
  const html = document.documentElement;
  const isDark = html.classList.toggle('dark');
  document.getElementById('theme-text').textContent = isDark
    ? 'Oscuro'
    : 'Claro';
  document
    .getElementById('theme-icon-sun')
    .setAttribute('data-lucide', isDark ? 'moon' : 'sun');
  lucide.createIcons();
  if (seagullChartInstance) loadShiftData();
}

function iniciarRelojEnVivo() {
  const relojEl = document.getElementById('live-clock');
  if (!relojEl) return;
  const meses = [
    'Ene',
    'Feb',
    'Mar',
    'Abr',
    'May',
    'Jun',
    'Jul',
    'Ago',
    'Sep',
    'Oct',
    'Nov',
    'Dic',
  ];

  function actualizar() {
    const ahora = new Date();
    const dia = String(ahora.getDate()).padStart(2, '0');
    const mes = meses[ahora.getMonth()];
    const anio = ahora.getFullYear();
    const hh = String(ahora.getHours()).padStart(2, '0');
    const mm = String(ahora.getMinutes()).padStart(2, '0');
    const ss = String(ahora.getSeconds()).padStart(2, '0');
    relojEl.textContent = `${dia} ${mes} ${anio} - ${hh}:${mm}:${ss}`;
  }

  actualizar();
  setInterval(actualizar, 1000);
}

function setCargando(estado) {
  const btnText = document.getElementById('btn-load-text');
  const btnIcon = document.getElementById('btn-load-icon');
  const btn = document.getElementById('btn-load-data');
  const bar = document.getElementById('top-progress-bar');

  if (estado) {
    if (btn) btn.disabled = true;
    if (btnText) btnText.textContent = 'Cargando...';
    if (btnIcon) {
      btnIcon.setAttribute('data-lucide', 'loader-2');
      btnIcon.classList.add('animate-spin');
    }
    if (bar) {
      bar.classList.remove('opacity-0');
      bar.style.width = '70%';
    }
  } else {
    if (btn) btn.disabled = false;
    if (btnText) btnText.textContent = 'Cargar';
    if (btnIcon) {
      btnIcon.setAttribute('data-lucide', 'refresh-cw');
      btnIcon.classList.remove('animate-spin');
    }
    if (bar) {
      bar.style.width = '100%';
      setTimeout(() => {
        bar.classList.add('opacity-0');
        bar.style.width = '0%';
      }, 300);
    }
  }
  lucide.createIcons();
}

async function loadShiftData() {
  const dateInput =
    document.getElementById('query-date')?.value ||
    new Date().toISOString().split('T')[0];
  const shiftInput = document.getElementById('query-shift')?.value || 'A';
  setCargando(true);

  try {
    const response = await fetch(
      `/api/v1/sic/balance?fecha=${dateInput}&turno=${shiftInput}`
    );
    if (!response.ok) throw new Error('Error consultando API SIC');
    const data = await response.json();

    // 1. Dinamismo de Período y Fecha
    actualizarCabecera(dateInput, data.semana);
    refrescarModalFlotaActivo();

    // 2. Última Actualización con el texto requerido
    const lastDbEl = document.getElementById('last-db-update');
    if (lastDbEl) lastDbEl.textContent = data.ultima_actualizacion;

    const k = data.kpis;
    const signoDesvio = k.desvio_hora >= 0 ? '+' : '';
    const signoProy = k.desvio_proyeccion >= 0 ? '+' : '';

    // 3. Tarjeta 1: Acumulado a la Hora, Cumplimiento y Metas
    const card1Title = document.getElementById('card-accumulated-title');
    const card1H3 = document.getElementById('card-accumulated-ton');
    const badgeCumpl = document.getElementById('card-accumulated-badge');
    const elPlanTurno = document.getElementById('card-plan-turno');
    const elPlanMensual = document.getElementById('card-plan-mensual');
    const labelPlanTurno = document.getElementById('card-label-plan-turno');

    if (labelPlanTurno) {
      labelPlanTurno.textContent =
        shiftInput === 'BOTH' || shiftInput === 'INTER'
          ? 'Plan Día: '
          : 'Plan Turno: ';
    }

    if (card1Title) {
      card1Title.textContent =
        data.estado_operacional === 'CERRADO'
          ? `TOTAL REAL CIERRE (${k.total_horas}H CERRADAS)`
          : `ACUMULADO HORA (H${k.horas_transcurridas} de ${k.total_horas}H)`;
    }

    if (card1H3) {
      card1H3.innerHTML = ` ${fmt(k.ton_real_acum)} / ${fmt(k.ton_plan_hora)} Ton `;
    }

    if (badgeCumpl) {
      badgeCumpl.textContent = `${fmt(k.cumpl_hora)}%`;
      badgeCumpl.className = `text-[10px] font-bold px-1.5 py-0.5 rounded ${
        k.cumpl_hora >= 100
          ? 'text-emerald-400 bg-emerald-950/40'
          : 'text-rose-400 bg-rose-950/40'
      }`;
    }

    if (elPlanTurno) elPlanTurno.textContent = fmt(k.meta_total);
    if (elPlanMensual) {
      elPlanMensual.textContent = fmt(k.meta_plan_mensual || k.meta_total);
    }

    // 4. Tarjeta 2: Proyectado Turno
    const tituloCard2 = document.getElementById('card-proj-title');
    const h3Proy = document.getElementById('card-proj-ton');
    const badgeProy = document.getElementById('card-proj-badge');

    if (tituloCard2 && h3Proy && badgeProy) {
      if (data.estado_operacional === 'CERRADO') {
        tituloCard2.textContent = 'RESULTADO FINAL TURNO (CERRADO)';
        h3Proy.innerHTML = `${fmt(k.proyeccion)} Ton Real`;
        badgeProy.textContent = `Final: ${fmt(k.cumpl_proyeccion)}% (${signoProy}${fmt(k.desvio_proyeccion)} Ton)`;
      } else if (data.estado_operacional === 'FUTURO') {
        tituloCard2.textContent = 'PROYECCIÓN TURNO (PENDIENTE)';
        h3Proy.innerHTML = `0 Ton`;
        badgeProy.textContent = 'Sin Iniciar';
      } else {
        tituloCard2.textContent = 'PROYECTADO AL CIERRE (SIC)';
        h3Proy.innerHTML = `${fmt(k.proyeccion)} Ton`;
        badgeProy.textContent = `${signoProy}${fmt(k.desvio_proyeccion)} Ton (${fmt(k.cumpl_proyeccion)}%)`;
      }
      badgeProy.className = `text-[10px] font-bold px-1.5 py-0.5 rounded ${
        k.cumpl_proyeccion >= 100
          ? 'text-emerald-400 bg-emerald-950/40'
          : 'text-rose-400 bg-rose-950/40'
      }`;
    }

    // 5. Renderizado Seguro del Gráfico Gaviota
    renderSeagullChart(data.horas_labels, data.plan_series, data.real_series);

    // 5.b. Carga dinámica de Tablas SIC de Carguío y Transporte
    await cargarTablaCarguioSIC(dateInput, shiftInput);
    await cargarTablaTransporteSIC(dateInput, shiftInput);

    // 6. Consulta del Estado de Flota FMS para la Tarjeta 3
    fetch(`/api/v1/fleet/status?fecha=${dateInput}&turno=${shiftInput}`)
      .then((res) => res.json())
      .then((resFlota) => {
        if (resFlota.status === 'ok') {
          const f = resFlota.data;
          const elCaex = document.getElementById('card3-caex-status');
          const elCarg = document.getElementById('card3-loading-status');
          const elMant = document.getElementById('card3-mantencion-count');
          if (elCaex) elCaex.textContent = `${f.caex_disponibles} / ${f.caex_total}`;
          if (elCarg) elCarg.textContent = `${f.cargadores_disponibles} / ${f.cargadores_total}`;
          if (elMant) elMant.textContent = `${f.fuera_servicio} Equipos`;
        }
      })
      .catch((err) => console.error('Error al obtener flota FMS:', err));
  } catch (err) {
    console.error('Error al cargar datos del turno:', err);
  } finally {
    setCargando(false);
  }
}

function actualizarCabecera(fechaStr, semanaTag) {
  const meses = [
    'Enero',
    'Febrero',
    'Marzo',
    'Abril',
    'Mayo',
    'Junio',
    'Julio',
    'Agosto',
    'Septiembre',
    'Octubre',
    'Noviembre',
    'Diciembre',
  ];
  const [anio, mes, dia] = fechaStr.split('-').map(Number);
  const nombreMes = meses[mes - 1];
  const mainHeader = document.querySelector('#main-container header');
  if (mainHeader) {
    const badgePeriodo = mainHeader.querySelector('span.rounded-full');
    if (badgePeriodo) {
      badgePeriodo.textContent = `Fase 15 B • ${nombreMes} ${anio} (${semanaTag})`;
    }
  }
}

function renderSeagullChart(labels, planData, realData) {
  const canvas = document.getElementById('seagullChart');
  if (!canvas) return;

  if (seagullChartInstance) {
    seagullChartInstance.destroy();
    seagullChartInstance = null;
  }

  const ctx = canvas.getContext('2d');
  const isDark = document.documentElement.classList.contains('dark');

  const responsiveDataLabelsPlugin = {
    id: 'responsiveDataLabelsPlugin',
    afterDatasetsDraw(chart) {
      const { ctx } = chart;
      const isMobile = window.innerWidth < 768;

      chart.data.datasets.forEach((dataset, datasetIndex) => {
        const meta = chart.getDatasetMeta(datasetIndex);
        if (!meta.hidden) {
          meta.data.forEach((element, index) => {
            const val = dataset.data[index];
            if (val !== null && val !== undefined) {
              const pos = element.tooltipPosition();
              const texto = fmt(val) + ' Ton';
              ctx.save();
              ctx.font =
                'bold ' + (isMobile ? '9px' : '10px') + ' Inter, sans-serif';
              const textWidth = ctx.measureText(texto).width;
              const boxWidth = textWidth + 10;
              const boxHeight = 16;
              let posX = pos.x;
              let posY = datasetIndex === 0 ? pos.y - 15 : pos.y + 15;

              ctx.beginPath();
              ctx.roundRect(
                posX - boxWidth / 2,
                posY - boxHeight / 2,
                boxWidth,
                boxHeight,
                4
              );
              ctx.fillStyle =
                datasetIndex === 0
                  ? 'rgba(255, 200, 0, 0.95)'
                  : 'rgba(11, 37, 69, 0.95)';
              ctx.fill();
              ctx.lineWidth = 1;
              ctx.strokeStyle = datasetIndex === 0 ? '#d9a800' : '#07182E';
              ctx.stroke();
              ctx.fillStyle = datasetIndex === 0 ? '#07182E' : '#FFFFFF';
              ctx.textAlign = 'center';
              ctx.textBaseline = 'middle';
              ctx.fillText(texto, posX, posY);
              ctx.restore();
            }
          });
        }
      });
    },
  };

  seagullChartInstance = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [
        {
          type: 'line',
          label: 'Plan',
          data: planData,
          borderColor: '#FFC800',
          backgroundColor: '#FFC800',
          borderWidth: 2.5,
          pointRadius: 4,
          pointBackgroundColor: '#0B2545',
          pointBorderColor: '#FFC800',
          pointBorderWidth: 2,
          tension: 0.2,
          order: 1,
        },
        {
          type: 'bar',
          label: 'Real',
          data: realData,
          backgroundColor: '#0B2545',
          borderRadius: 4,
          order: 2,
        },
      ],
    },
    plugins: [responsiveDataLabelsPlugin],
    options: {
      responsive: true,
      maintainAspectRatio: false,
      layout: {
        padding: { top: 26, bottom: 12, left: 8, right: 8 },
      },
      plugins: {
        datalabels: { display: false },
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (c) =>
              `${c.dataset.label}: ${c.raw !== null ? fmt(c.raw) + ' Ton' : 'Sin datos'}`,
          },
        },
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: {
            font: {
              family: 'Inter',
              size: labels.length > 12 ? 9 : 10,
              weight: '700',
            },
            color: function (context) {
              const r = realData[context.index];
              const p = planData[context.index];
              if (r === null || r === undefined)
                return isDark ? '#94a3b8' : '#64748b';
              return r >= p ? '#10b981' : '#ef4444';
            },
          },
        },
        y: {
          beginAtZero: true,
          grid: { color: isDark ? '#1e293b' : '#f1f5f9' },
          ticks: {
            font: { family: 'Inter', size: 10 },
            color: '#94a3b8',
            callback: (v) => fmt(v),
          },
        },
      },
    },
  });
}

window.onload = function () {
  iniciarRelojEnVivo();
  const ahora = new Date();
  const hora = ahora.getHours();
  let turnoAuto = 'A';
  let fechaOperacional = new Date(ahora);

  if (hora >= 8 && hora < 20) {
    turnoAuto = 'A';
  } else {
    turnoAuto = 'B';
    if (hora < 8) {
      fechaOperacional.setDate(fechaOperacional.getDate() - 1);
    }
  }

  const yyyy = fechaOperacional.getFullYear();
  const mm = String(fechaOperacional.getMonth() + 1).padStart(2, '0');
  const dd = String(fechaOperacional.getDate()).padStart(2, '0');
  const fechaStr = `${yyyy}-${mm}-${dd}`;

  const inputFecha = document.getElementById('query-date');
  if (inputFecha) inputFecha.value = fechaStr;

  const selectTurno = document.getElementById('query-shift');
  if (selectTurno) selectTurno.value = turnoAuto;

  loadShiftData();
};

let chartCaexVsTon = null;
let chartAsarcoTimeline = null;

window.cerrarModalFlota = function () {
  const modal = document.getElementById('modal-flota');
  const content = document.getElementById('modal-flota-content');
  if (modal && content) {
    modal.classList.remove('opacity-100');
    modal.classList.add('opacity-0');
    modal.classList.add('pointer-events-none');
    content.classList.remove('scale-100');
    content.classList.add('scale-95');
  }
};

document.addEventListener('DOMContentLoaded', () => {
  const modal = document.getElementById('modal-flota');
  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        window.cerrarModalFlota();
      }
    });
  }
});

async function cargarDetalleFallasFlota() {
  const dateInput =
    document.getElementById('query-date')?.value || '2026-10-06';
  const shiftInput = document.getElementById('query-shift')?.value || 'A';
  const contFallas = document.getElementById('modal-equipos-falla');

  try {
    const resp = await fetch(
      `/api/v1/fleet/status?fecha=${dateInput}&turno=${shiftInput}`
    );
    const json = await resp.json();
    if (json.status === 'ok' && contFallas) {
      const fallas = json.data.equipos_detenidos || [];
      if (fallas.length === 0) {
        contFallas.innerHTML = `Sin equipos en mantención en este momento. Flota 100% nominal operativa.`;
      } else {
        contFallas.innerHTML = fallas
          .map(
            (f) => ` 
 <span class="px-2 py-0.5 rounded bg-rose-100 dark:bg-rose-900/40 text-rose-800 dark:text-rose-300 font-bold border border-rose-200 dark:border-rose-800">
   ${f.equipo} - ${f.razon}
 </span> 
 `
          )
          .join('');
      }
    }
  } catch (err) {
    console.error('Error al cargar detalle de fallas:', err);
  }
}

async function cargarGraficoCaexVsTon() {
  const spinner = document.getElementById('spinner-caex');
  if (spinner) spinner.classList.remove('hidden');

  const dateInput = document.getElementById('query-date')?.value;
  const shiftInput = document.getElementById('query-shift')?.value;
  const canvas = document.getElementById('caexVsTonChart');

  if (!canvas) {
    if (spinner) spinner.classList.add('hidden');
    return;
  }

  try {
    const resp = await fetch(
      `/api/v1/fleet/caex-vs-ton?fecha=${dateInput}&turno=${shiftInput}`
    );
    const resJson = await resp.json();
    if (resJson.status !== 'ok') return;

    const items = resJson.data;
    const labels = items.map((d) => `H${d.hora}`);
    const dataCaexDisp = items.map((d) => d.caex_activos);
    const dataCaexOper = items.map((d) => d.caex_operativos);
    const dataTon = items.map((d) => d.tonelaje);

    if (chartCaexVsTon) {
      chartCaexVsTon.destroy();
      chartCaexVsTon = null;
    }

    const isDark = document.documentElement.classList.contains('dark');
    const textColor = isDark ? '#94a3b8' : '#475569';
    const gridColor = isDark
      ? 'rgba(255, 255, 255, 0.05)'
      : 'rgba(0, 0, 0, 0.06)';
    const ctx = canvas.getContext('2d');

    chartCaexVsTon = new Chart(ctx, {
      data: {
        labels: labels,
        datasets: [
          {
            type: 'bar',
            label: 'Tonelaje Movido (Ton)',
            data: dataTon,
            backgroundColor: isDark
              ? 'rgba(37, 99, 235, 0.45)'
              : 'rgba(37, 99, 235, 0.65)',
            borderColor: '#2563eb',
            borderWidth: 1.5,
            borderRadius: 6,
            yAxisID: 'yTon',
            order: 3,
            datalabels: {
              display: (context) => {
                const val = context.dataset.data[context.dataIndex];
                return val !== null && val > 0;
              },
              anchor: 'center',
              align: 'center',
              color: '#ffffff',
              font: { size: 9, weight: 'bold' },
              formatter: (val) =>
                val > 0 ? Math.round(val).toLocaleString('es-CL') : '',
            },
          },
          {
            type: 'line',
            label: 'CAEX Disponibles',
            data: dataCaexDisp,
            borderColor: '#d97706',
            backgroundColor: '#d97706',
            pointBackgroundColor: '#d97706',
            pointBorderColor: '#ffffff',
            pointBorderWidth: 2,
            pointRadius: 4,
            borderWidth: 2.5,
            tension: 0.2,
            yAxisID: 'yCaex',
            order: 1,
            spanGaps: false,
            datalabels: {
              display: (context) =>
                context.dataset.data[context.dataIndex] !== null,
              anchor: 'end',
              align: 'top',
              offset: 4,
              color: '#ffffff',
              backgroundColor: '#b45309',
              borderColor: '#d97706',
              borderWidth: 1,
              borderRadius: 4,
              padding: { top: 2, bottom: 2, left: 4, right: 4 },
              font: { size: 10, weight: 'bold' },
              formatter: (val) => (val !== null ? `${val}` : ''),
            },
          },
          {
            type: 'line',
            label: 'CAEX Operativos',
            data: dataCaexOper,
            borderColor: '#10b981',
            backgroundColor: '#10b981',
            pointBackgroundColor: '#10b981',
            pointBorderColor: '#ffffff',
            pointBorderWidth: 2,
            pointRadius: 4,
            borderWidth: 2.5,
            tension: 0.2,
            yAxisID: 'yCaex',
            order: 2,
            spanGaps: false,
            datalabels: {
              display: (context) =>
                context.dataset.data[context.dataIndex] !== null,
              anchor: 'start',
              align: 'bottom',
              offset: 4,
              color: '#ffffff',
              backgroundColor: '#047857',
              borderColor: '#10b981',
              borderWidth: 1,
              borderRadius: 4,
              padding: { top: 2, bottom: 2, left: 4, right: 4 },
              font: { size: 10, weight: 'bold' },
              formatter: (val) => (val !== null ? `${val}` : ''),
            },
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        layout: {
          padding: { top: 24, bottom: 12 },
        },
        interaction: {
          mode: 'index',
          intersect: false,
        },
        plugins: {
          legend: {
            position: 'top',
            labels: {
              color: textColor,
              font: { size: 11, weight: '600' },
              boxWidth: 12,
            },
          },
        },
        scales: {
          x: {
            grid: { color: gridColor },
            ticks: { color: textColor, font: { size: 10 } },
          },
          yTon: {
            type: 'linear',
            position: 'left',
            beginAtZero: true,
            title: {
              display: true,
              text: 'Tonelaje (Ton)',
              color: textColor,
              font: { size: 10 },
            },
            grid: { color: gridColor },
            ticks: { color: textColor, font: { size: 10 } },
          },
          yCaex: {
            type: 'linear',
            position: 'right',
            beginAtZero: true,
            max: 14,
            title: {
              display: true,
              text: 'Flota CAEX (Unidades)',
              color: '#d97706',
              font: { size: 10 },
            },
            grid: { drawOnChartArea: false },
            ticks: {
              color: '#d97706',
              stepSize: 2,
              font: { size: 10 },
            },
          },
        },
      },
    });
    chartCaexVsTon.resize();
  } catch (e) {
    console.error('Error al renderizar gráfico CAEX vs Ton:', e);
  } finally {
    if (spinner) spinner.classList.add('hidden');
  }
}

function refrescarModalFlotaActivo() {
  const modal = document.getElementById('modal-flota');
  if (!modal) return;
  const estaVisible =
    !modal.classList.contains('pointer-events-none') &&
    !modal.classList.contains('hidden');

  if (estaVisible) {
    cargarDetalleFallasFlota();
    cargarGraficoCaexVsTon();
    cargarGraficoTimelineASARCO();
  }
}

document
  .getElementById('query-shift')
  ?.addEventListener('change', refrescarModalFlotaActivo);
document
  .getElementById('query-date')
  ?.addEventListener('change', refrescarModalFlotaActivo);

window.abrirModalFlota = function () {
  const modal = document.getElementById('modal-flota');
  const content = document.getElementById('modal-flota-content');

  if (modal && content) {
    modal.classList.remove('pointer-events-none', 'opacity-0');
    modal.classList.add('opacity-100');
    content.classList.remove('scale-95');
    content.classList.add('scale-100');

    if (window.lucide) window.lucide.createIcons();

    setTimeout(() => {
      cargarDetalleFallasFlota();
      cargarGraficoCaexVsTon();
      cargarGraficoTimelineASARCO();
    }, 150);
  }
};

async function cargarGraficoTimelineASARCO() {
  const spinner = document.getElementById('spinner-timeline');
  if (spinner) spinner.classList.remove('hidden');

  const fechaInput = document.getElementById('query-date');
  const turnoInput = document.getElementById('query-shift');
  const canvas = document.getElementById('asarcoTimelineChart');

  if (!canvas) {
    if (spinner) spinner.classList.add('hidden');
    return;
  }

  const fecha = fechaInput?.value;
  const turno = turnoInput?.value;
  const url = `/api/v1/fleet/timeline?fecha=${fecha}&turno=${turno}`;

  try {
    const resp = await fetch(url);
    if (!resp.ok) throw new Error(`HTTP Error: ${resp.status}`);
    const resJson = await resp.json();
    if (resJson.status !== 'ok' || !resJson.data) return;

    const timelineData = resJson.data;
    const ordenEquipos = [
      'L02',
      'L03',
      'L04',
      'L05',
      'L06',
      'T11',
      'T12',
      'T13',
      'T15',
      'T16',
      'T17',
      'T18',
      'T19',
      'T20',
      'T21',
      'T23',
      'T24',
      'T83',
      'T86',
    ];

    const dataOper = [];
    const dataDemora = [];
    const dataMant = [];
    const dataReserva = [];

    ordenEquipos.forEach((eq) => {
      const eventos = timelineData[eq] || [];
      eventos.forEach((ev) => {
        const punto = {
          x: [ev.start_h, ev.end_h],
          y: eq,
          motivo: ev.motivo,
          hora_inicio: ev.hora_inicio,
          duracion: ev.duracion,
        };
        if (ev.categoria === 'OPERACIONAL') dataOper.push(punto);
        else if (ev.categoria === 'DEMORA') dataDemora.push(punto);
        else if (ev.categoria === 'MANTENCION') dataMant.push(punto);
        else if (ev.categoria === 'RESERVA') dataReserva.push(punto);
      });
    });

    if (chartAsarcoTimeline) {
      chartAsarcoTimeline.destroy();
      chartAsarcoTimeline = null;
    }

    const isDark = document.documentElement.classList.contains('dark');
    const textColor = isDark ? '#cbd5e1' : '#334155';
    const gridColor = isDark
      ? 'rgba(255, 255, 255, 0.05)'
      : 'rgba(0, 0, 0, 0.06)';
    const ctx = canvas.getContext('2d');

    chartAsarcoTimeline = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ordenEquipos,
        datasets: [
          {
            label: 'Operativo',
            data: dataOper,
            backgroundColor: '#198754',
            grouped: false,
            barPercentage: 0.85,
            categoryPercentage: 0.9,
            catKey: 'OPERACIONAL',
          },
          {
            label: 'Demora',
            data: dataDemora,
            backgroundColor: '#0d6efd',
            grouped: false,
            barPercentage: 0.85,
            categoryPercentage: 0.9,
            catKey: 'DEMORA',
          },
          {
            label: 'Mantenimiento',
            data: dataMant,
            backgroundColor: '#dc3545',
            grouped: false,
            barPercentage: 0.85,
            categoryPercentage: 0.9,
            catKey: 'MANTENCION',
          },
          {
            label: 'Reserva',
            data: dataReserva,
            backgroundColor: '#ffc107',
            grouped: false,
            barPercentage: 0.85,
            categoryPercentage: 0.9,
            catKey: 'RESERVA',
          },
        ],
      },
      options: {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: {
            stacked: false,
            min: 0,
            max: 12,
            title: {
              display: true,
              text: 'Línea de Tiempo del Turno (Horas 0 a 12)',
              color: textColor,
              font: { size: 10, weight: 'bold' },
            },
            grid: { color: gridColor },
            ticks: { color: textColor, font: { size: 10 }, stepSize: 1 },
          },
          y: {
            stacked: false,
            grid: { color: gridColor },
            ticks: {
              color: textColor,
              font: { size: 10, weight: 'bold' },
            },
          },
        },
        plugins: {
          legend: {
            position: 'top',
            labels: {
              color: textColor,
              font: { size: 11, weight: '600' },
              boxWidth: 12,
            },
          },
          datalabels: {
            display: (context) => {
              const raw = context.dataset.data[context.dataIndex];
              if (!raw || !raw.x) return false;
              const dur = raw.x[1] - raw.x[0];
              return dur >= 0.8;
            },
            color: '#ffffff',
            font: { size: 9, weight: 'bold' },
            formatter: (val, context) => {
              const raw = context.dataset.data[context.dataIndex];
              const dur = raw.x[1] - raw.x[0];
              return `${dur.toFixed(1)}h`;
            },
          },
          tooltip: {
            backgroundColor: '#07182E',
            titleColor: '#ffffff',
            bodyColor: '#e2e8f0',
            borderColor: '#334155',
            borderWidth: 1,
            padding: 10,
            callbacks: {
              label: function (context) {
                const raw = context.raw;
                if (!raw) return '';
                const dur = (raw.x[1] - raw.x[0]).toFixed(1);
                return ` ${context.dataset.label}: ${dur} hrs`;
              },
              afterLabel: function (context) {
                const raw = context.raw;
                if (!raw) return null;
                return [
                  ` Motivo: ${raw.motivo}`,
                  ` Inicio: ${raw.hora_inicio} hrs (${raw.x[0].toFixed(1)}h del turno)`,
                ];
              },
            },
          },
        },
      },
    });
    chartAsarcoTimeline.resize();
  } catch (e) {
    console.error('Error al renderizar Timeline ASARCO:', e);
  } finally {
    if (spinner) spinner.classList.add('hidden');
  }
}

setInterval(loadShiftData, 300000);

// =========================================================================
// HELPER PARA ALINEAR ANCHOS DE COLUMNAS DE TABLAS SIC (CARGUÍO Y TRANSPORTE)
// =========================================================================
function fijarAnchosTabla(elementInTable) {
  if (!elementInTable) return;
  const table = elementInTable.closest('table');
  if (!table) return;
  table.style.tableLayout = 'fixed';
  table.style.width = '100%';
  table.classList.add('table-fixed', 'w-full');
  const widthPercentages = ['22%', '14%', '14%', '14%', '16%', '20%'];
  const ths = table.querySelectorAll('thead th');
  ths.forEach((th, i) => {
    if (widthPercentages[i]) {
      th.style.width = widthPercentages[i];
      th.classList.add(`w-[${widthPercentages[i]}]`);
    }
  });
}

// =========================================================================
// RENDERING TABLAS SIC (CARGUÍO Y TRANSPORTE)
// =========================================================================
async function cargarTablaCarguioSIC(dateInput, shiftInput) {
  const tbody = document.getElementById('carguio-tbody');
  const tfoot = document.getElementById('carguio-tfoot');
  const badgeSummary = document.getElementById('carguio-badge-summary');
  if (!tbody || !tfoot) return;

  try {
    const resp = await fetch(
      `/api/v1/sic/carguio?fecha=${dateInput}&turno=${shiftInput}`
    );
    if (!resp.ok) {
      if (badgeSummary) badgeSummary.innerHTML = `Error HTTP ${resp.status}`;
      return;
    }
    const resJson = await resp.json();
    const isOk = resJson.status === 'success' || resJson.status === 'ok';

    if (!isOk || !resJson.data) {
      if (badgeSummary) badgeSummary.innerHTML = `Sin Respuesta API`;
      return;
    }

    const data = resJson.data;
    if (!Array.isArray(data) || data.length === 0) {
      tbody.innerHTML = `Sin registros para el turno seleccionado`;
      if (badgeSummary) badgeSummary.innerHTML = `Sin Datos`;
      return;
    }

    const equiposIndiv = data.filter((item) => item.equipo !== 'TOTAL CARGUIO');
    const totalCarguio = data.find((item) => item.equipo === 'TOTAL CARGUIO');

    const nombresEquipo = {
      L03: 'WA 600 (L03)',
      L04: 'WA 600 (L04)',
      L05: 'Cat 992 (L05)',
      L06: 'Cat 992 (L06)',
    };

    let htmlRows = '';
    equiposIndiv.forEach((eq) => {
      const nombreMostrar = nombresEquipo[eq.equipo] || `Cargador (${eq.equipo})`;
      let statusBadge = '';
      if (eq.cumpl_pct >= 100 || eq.ton_plan === 0) {
        statusBadge = `● Óptimo`;
      } else if (eq.cumpl_pct >= 90) {
        statusBadge = `● En Meta`;
      } else {
        statusBadge = `● Desviado`;
      }

      const colorTon =
        eq.cumpl_pct >= 100 || eq.ton_plan === 0
          ? 'text-emerald-600 dark:text-emerald-400'
          : 'text-rose-600 dark:text-rose-400';

      htmlRows += `
        <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition">
          <td class="py-2.5 px-2 font-bold text-slate-900 dark:text-white">${nombreMostrar}</td>
          <td class="py-2 px-2 text-center">
            <span class="${
              eq.cumpl_pct >= 90 || eq.ton_plan === 0
                ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400'
                : 'bg-rose-50 dark:bg-rose-950 text-rose-600 dark:text-rose-400'
            } px-2 py-0.5 rounded font-bold text-[10px]">${statusBadge}</span>
          </td>
          <td class="py-2 px-2 text-center">
            ${eq.df_real_pct}% <span class="text-[10px] text-slate-400">/${eq.df_plan_pct}%</span>
          </td>
          <td class="py-2 px-2 text-center">
            ${eq.utbd_real_pct}% <span class="text-[10px] text-slate-400">/${eq.utbd_plan_pct}%</span>
          </td>
          <td class="py-2 px-2 text-center font-bold">
            ${fmt(eq.rend_real)} <span class="text-[10px] text-slate-400 font-normal">/${fmt(eq.rend_plan)}</span>
          </td>
          <td class="py-2.5 px-2 text-right font-black ${colorTon}">
            ${fmt(eq.ton_real)} Ton <span class="text-[10px] text-slate-400 font-medium">/ ${fmt(eq.ton_plan)} Ton</span>
          </td>
        </tr>
      `;
    });
    tbody.innerHTML = htmlRows;

    if (totalCarguio) {
      const cumplTotal = totalCarguio.cumpl_pct;
      const isOk = cumplTotal >= 100 || totalCarguio.ton_plan === 0;

      if (badgeSummary) {
        badgeSummary.innerHTML = `
          <span class="w-2 h-2 rounded-full ${isOk ? 'bg-emerald-500' : 'bg-rose-500'}"></span>
          <span>${isOk ? 'Cumpliendo' : 'Desviado'} (${cumplTotal}%)</span>
        `;
        badgeSummary.className = `text-[10px] font-bold px-2 py-0.5 rounded flex items-center space-x-1 ${
          isOk
            ? 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950 dark:text-emerald-400'
            : 'text-rose-600 bg-rose-50 dark:bg-rose-950 dark:text-rose-400'
        }`;
      }

      tfoot.innerHTML = `
        <tr>
          <td class="py-2.5 px-2 text-hmcBlue dark:text-amber-400">TOTAL CARGUIO</td>
          <td class="py-2 px-2 text-center text-slate-400 text-[10px] font-semibold">${cumplTotal}% Cumpl.</td>
          <td class="py-2 px-2 text-center text-slate-800 dark:text-white">${totalCarguio.df_real_pct}% <span class="text-[10px] text-slate-400">/${totalCarguio.df_plan_pct}%</span></td>
          <td class="py-2 px-2 text-center text-slate-800 dark:text-white">${totalCarguio.utbd_real_pct}% <span class="text-[10px] text-slate-400">/${totalCarguio.utbd_plan_pct}%</span></td>
          <td class="py-2 px-2 text-center text-slate-800 dark:text-white">${fmt(totalCarguio.rend_real)} <span class="text-[10px] text-slate-400 font-normal">/${fmt(totalCarguio.rend_plan)} Ton/h</span></td>
          <td class="py-2.5 px-2 text-right text-hmcBlue dark:text-amber-400">${fmt(totalCarguio.ton_real)} Ton <span class="text-[10px] text-slate-400 font-medium">/ ${fmt(totalCarguio.ton_plan)} Ton</span></td>
        </tr>
      `;
      fijarAnchosTabla(tbody);
    }
  } catch (err) {
    console.error('❌ Excepción en cargarTablaCarguioSIC:', err);
    if (badgeSummary) badgeSummary.innerHTML = `Error de Ejecución`;
  }
}

async function cargarTablaTransporteSIC(dateInput, shiftInput) {
  const tbody = document.getElementById('transporte-tbody');
  const tfoot = document.getElementById('transporte-tfoot');
  const badgeSummary = document.getElementById('transporte-badge-summary');
  if (!tbody || !tfoot) return;

  try {
    const resp = await fetch(
      `/api/v1/sic/transporte?fecha=${dateInput}&turno=${shiftInput}`
    );
    if (!resp.ok) {
      if (badgeSummary) badgeSummary.innerHTML = `Error HTTP ${resp.status}`;
      return;
    }
    const resJson = await resp.json();
    const isOk = resJson.status === 'success' || resJson.status === 'ok';

    if (!isOk || !resJson.data) {
      if (badgeSummary) badgeSummary.innerHTML = `Sin Respuesta API`;
      return;
    }

    const data = resJson.data;
    if (!Array.isArray(data) || data.length === 0) {
      tbody.innerHTML = `Sin registros para el turno seleccionado`;
      if (badgeSummary) badgeSummary.innerHTML = `Sin Datos`;
      return;
    }

    const flotasIndiv = data.filter(
      (item) => item.flota !== 'TOTAL TRANSPORTE'
    );
    const totalTransporte = data.find(
      (item) => item.flota === 'TOTAL TRANSPORTE'
    );

    const nombresFlota = {
      'FLOTA CAT 775': 'CAEX 775 (12x)',
      'FLOTA CAT 777': 'CAEX 777 (2x)',
    };

    let htmlRows = '';
    flotasIndiv.forEach((fl) => {
      const nombreMostrar = nombresFlota[fl.flota] || fl.flota;
      let statusBadge = '';
      if (fl.cumpl_pct >= 100 || fl.ton_plan === 0) {
        statusBadge = `● Óptimo`;
      } else if (fl.cumpl_pct >= 90) {
        statusBadge = `● En Meta`;
      } else {
        statusBadge = `● Desviado`;
      }

      const colorTon =
        fl.cumpl_pct >= 100 || fl.ton_plan === 0
          ? 'text-emerald-600 dark:text-emerald-400'
          : 'text-rose-600 dark:text-rose-400';

      htmlRows += `
        <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition">
          <td class="py-2.5 px-2 font-bold text-slate-900 dark:text-white">${nombreMostrar}</td>
          <td class="py-2 px-2 text-center">
            <span class="${
              fl.cumpl_pct >= 90 || fl.ton_plan === 0
                ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400'
                : 'bg-rose-50 dark:bg-rose-950 text-rose-600 dark:text-rose-400'
            } px-2 py-0.5 rounded font-bold text-[10px]">${statusBadge}</span>
          </td>
          <td class="py-2 px-2 text-center">
            ${fl.df_real_pct}% <span class="text-[10px] text-slate-400">/${fl.df_plan_pct}%</span>
          </td>
          <td class="py-2 px-2 text-center">
            ${fl.utbd_real_pct}% <span class="text-[10px] text-slate-400">/${fl.utbd_plan_pct}%</span>
          </td>
          <td class="py-2 px-2 text-center font-bold">
            ${fmt(fl.rend_real)} <span class="text-[10px] text-slate-400 font-normal">/${fmt(fl.rend_plan)}</span>
          </td>
          <td class="py-2.5 px-2 text-right font-black ${colorTon}">
            ${fmt(fl.ton_real)} Ton <span class="text-[10px] text-slate-400 font-medium">/ ${fmt(fl.ton_plan)} Ton</span>
          </td>
        </tr>
      `;
    });
    tbody.innerHTML = htmlRows;

    if (totalTransporte) {
      const cumplTotal = totalTransporte.cumpl_pct;
      const isOk = cumplTotal >= 100 || totalTransporte.ton_plan === 0;

      if (badgeSummary) {
        badgeSummary.innerHTML = `
          <span class="w-2 h-2 rounded-full ${isOk ? 'bg-emerald-500' : 'bg-rose-500'}"></span>
          <span>${isOk ? 'Cumpliendo' : 'Desviado'} (${cumplTotal}%)</span>
        `;
        badgeSummary.className = `text-[10px] font-bold px-2 py-0.5 rounded flex items-center space-x-1 ${
          isOk
            ? 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950 dark:text-emerald-400'
            : 'text-rose-600 bg-rose-50 dark:bg-rose-950 dark:text-rose-400'
        }`;
      }

      tfoot.innerHTML = `
        <tr>
          <td class="py-2.5 px-2 text-hmcBlue dark:text-amber-400">TOTAL TRANSPORTE</td>
          <td class="py-2 px-2 text-center text-slate-400 text-[10px] font-semibold">${cumplTotal}% Cumpl.</td>
          <td class="py-2 px-2 text-center text-slate-800 dark:text-white">${totalTransporte.df_real_pct}% <span class="text-[10px] text-slate-400">/${totalTransporte.df_plan_pct}%</span></td>
          <td class="py-2 px-2 text-center text-slate-800 dark:text-white">${totalTransporte.utbd_real_pct}% <span class="text-[10px] text-slate-400">/${totalTransporte.utbd_plan_pct}%</span></td>
          <td class="py-2 px-2 text-center text-slate-800 dark:text-white">${fmt(totalTransporte.rend_real)} <span class="text-[10px] text-slate-400 font-normal">/${fmt(totalTransporte.rend_plan)} Ton/h</span></td>
          <td class="py-2.5 px-2 text-right text-hmcBlue dark:text-amber-400">${fmt(totalTransporte.ton_real)} Ton <span class="text-[10px] text-slate-400 font-medium">/ ${fmt(totalTransporte.ton_plan)} Ton</span></td>
        </tr>
      `;
      fijarAnchosTabla(tbody);
    }
  } catch (err) {
    console.error('❌ Excepción en cargarTablaTransporteSIC:', err);
    if (badgeSummary) badgeSummary.innerHTML = `Error de Ejecución`;
  }
}